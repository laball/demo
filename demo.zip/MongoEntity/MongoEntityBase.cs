﻿using MongoDB.Bson;

namespace MongoEntity
{
    public class MongoEntityBase
    {
        public ObjectId _id { get; set; }
    }
}
